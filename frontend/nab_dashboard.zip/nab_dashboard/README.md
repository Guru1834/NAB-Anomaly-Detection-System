# NAB Anomaly Detection Dashboard

A Streamlit dashboard for detecting anomalies in AWS CloudWatch time-series data using the [Numenta Anomaly Benchmark (NAB)](https://github.com/numenta/NAB) dataset.

## Features

- **5 detection methods** — GRU Autoencoder, Z-Score, IQR, Isolation Forest, Local Outlier Factor
- **Ensemble mode** — majority vote across all 5 methods
- **Interactive Plotly charts** — anomaly overlays, score timelines, training loss
- **Demo mode** — runs without any data file using synthetic time series
- **Export** — download results as CSV

## Quick start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the app

```bash
streamlit run app.py
```

The dashboard opens at `http://localhost:8501`

### 3. Upload your data

Upload any NAB CloudWatch CSV from:
```
NAB-master/data/realAWSCloudwatch/
```

Files that work well:
- `ec2_network_in_5abac7.csv`
- `ec2_cpu_utilization_53ea38.csv`
- `elb_request_count_8c0756.csv`

Expected CSV format:
```
timestamp,value
2014-02-26 21:42:53,57.0
2014-02-26 21:47:53,60.0
...
```

## Deploy to Streamlit Community Cloud (free)

1. Push this folder to a public GitHub repo
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your repo and point to `app.py`
4. Deploy — you get a public URL to put on your resume

## Parameters

| Parameter | Description | Default |
|---|---|---|
| Sequence length | GRU window size (time steps) | 30 |
| Max epochs | GRU training epochs | 50 |
| Threshold σ | Anomaly threshold = mean + σ × std | 2.5 |
| Train fraction | % of series used for training | 70% |
| Contamination | Expected anomaly % (IF / LOF) | 5% |

## Project structure

```
nab_dashboard/
├── app.py            # Main Streamlit application
├── requirements.txt  # Python dependencies
└── README.md         # This file
```
